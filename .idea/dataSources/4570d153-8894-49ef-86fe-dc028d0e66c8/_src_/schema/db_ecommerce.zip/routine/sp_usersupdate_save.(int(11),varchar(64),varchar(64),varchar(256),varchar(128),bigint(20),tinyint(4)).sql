CREATE PROCEDURE `sp_usersupdate_save`(`piduser`      INT(11), `pdesperson` VARCHAR(64), `pdeslogin` VARCHAR(64),
                                       `pdespassword` VARCHAR(256), `pdesemail` VARCHAR(128), `pnrphone` BIGINT(20),
                                       `pinadmin`     TINYINT(4))
  BEGIN
	
    DECLARE vidperson INT;
    
	SELECT idperson INTO vidperson
    FROM tb_users
    WHERE iduser = piduser;
    
    UPDATE tb_persons
    SET 
		desperson = pdesperson,
        desemail = pdesemail,
        nrphone = pnrphone
	WHERE idperson = vidperson;
    
    UPDATE tb_users
    SET
		deslogin = pdeslogin,
        despassword = pdespassword,
        inadmin = pinadmin
	WHERE iduser = piduser;
    
    SELECT * FROM tb_users a INNER JOIN tb_persons b USING(idperson) WHERE a.iduser = piduser;
    
END