create procedure sp_products_save(IN pidproduct int, IN pdesproduct varchar(64), IN pvlprice decimal(10, 2),
                                  IN pvlwidth   decimal(10, 2), IN pvlheight decimal(10, 2),
                                  IN pvllength  decimal(10, 2), IN pvlweight decimal(10, 2), IN pdesurl varchar(128))
  BEGIN
	
	IF pidproduct > 0 THEN
		
		UPDATE tb_products
        SET 
			desproduct = pdesproduct,
            vlprice = pvlprice,
            vlwidth = pvlwidth,
            vlheight = pvlheight,
            vllength = pvllength,
            vlweight = pvlweight,
            desurl = pdesurl
        WHERE idproduct = pidproduct;
        
    ELSE
		
		INSERT INTO tb_products (desproduct, vlprice, vlwidth, vlheight, vllength, vlweight, desurl) 
        VALUES(pdesproduct, pvlprice, pvlwidth, pvlheight, pvllength, pvlweight, pdesurl);
        
        SET pidproduct = LAST_INSERT_ID();
        
    END IF;
    
    SELECT * FROM tb_products WHERE idproduct = pidproduct;
    
END;

